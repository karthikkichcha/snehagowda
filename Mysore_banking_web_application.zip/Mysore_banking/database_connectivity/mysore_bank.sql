-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2023 at 04:35 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mysore_bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `bkid` int(11) NOT NULL,
  `account_no` varchar(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `contact` varchar(60) NOT NULL,
  `address` varchar(200) NOT NULL,
  `password` varchar(20) NOT NULL,
  `balance` float NOT NULL,
  `account_status` int(11) NOT NULL,
  `limit1` int(11) NOT NULL,
  `limit_c` float NOT NULL DEFAULT 0,
  `withdraw_limit` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`bkid`, `account_no`, `name`, `contact`, `address`, `password`, `balance`, `account_status`, `limit1`, `limit_c`, `withdraw_limit`) VALUES
(4, 'MYS939017556', 'Manjula R', '7899828926', '05 2nd cross\r\nMadevapura main road gandhinagar', '12345', 73545, 1, 4, 20000, 10000),
(5, 'MYS325699348', 'KARTHIK N R', '6363140789', '4068/7 11th cross gandhinagar chamundesh', '123', 6812, 3, 4, 20000, 10000),
(6, 'MYS346633334', 'N Siddaraju', '6363140789', '164\r\n1st stage 1st cross gaythripuram', '12345', 500, 1, 4, 20000, 20000),
(7, 'MYS440906725', 'N Siddaraju', '6363140789', '164\r\n1st stage 1st cross gaythripuram', '1234', 7500, 1, 4, 20000, 10000),
(8, 'MYS571363900', 'N Siddaraju', '6363140789', '164\r\n1st stage 1st cross gaythripuram', '1234', 15500, 1, 4, 20000, 10000),
(9, 'MYS673165897', 'N Siddaraju', '6363140789', '164\r\n1st stage 1st cross gaythripuram', '1234', 0, 1, 4, 20000, 20000),
(10, 'MYS835199075', 'N Siddaraju', '6363140789', '164\r\n1st stage 1st cross gaythripuram', '1234', 39100, 1, 4, 20000, 10000),
(11, 'MYS622300189', 'diksith', '8998392222', 'mysore', '123', 0, 1, 4, 20000, 10000),
(12, 'MYS1067676469', 'diksith', '8998392222', 'mysore', 'frytyjutm ', 0, 2, 4, 0, 10000),
(31, 'MYS239732589', 'chandra K', '9901241859', 'mysore', '123', 600, 1, 4, 20000, 20000),
(32, 'MYS1164340660', 'manjunath t', '9663237162', 'mysore', 'karuU123@', 1800, 1, 4, 20000, 20000),
(33, 'MYS1065797826', 'karthik kichchca', '6363140789', 'mysore', 'karthikK123@', 500, 1, 4, 20000, 20000),
(34, 'MYS866463382', 'chandra R', '6363140789', '#5068/7 lashkar mohall mysore', 'karthikK123@', 20299, 1, 4, 20000, 20000),
(35, 'MYS942198353', 'chandra R', '6363140789', '4068/7 11th cross gandhinagar chamundesh', 'karthikK123@', 3000, 1, 4, 20000, 20000);

-- --------------------------------------------------------

--
-- Table structure for table `log_table`
--

CREATE TABLE `log_table` (
  `logid` int(11) NOT NULL,
  `datelog` varchar(80) NOT NULL,
  `log_mode` varchar(80) NOT NULL,
  `account_number` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `log_table`
--

INSERT INTO `log_table` (`logid`, `datelog`, `log_mode`, `account_number`) VALUES
(95, '09-01-2023', 'sucess', 'MYS939017556'),
(103, '10-01-2023', 'sucess', 'MYS942198353'),
(104, '10-01-2023', 'failure', 'MYS939017556'),
(105, '10-01-2023', 'failure', 'MYS939017556'),
(106, '10-01-2023', 'failure', 'MYS939017556'),
(107, '10-01-2023', 'failure', 'MYS346633334'),
(108, '10-01-2023', 'failure', 'MYS346633334'),
(109, '10-01-2023', 'failure', 'MYS346633334');

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `username` int(11) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`username`, `password`) VALUES
(1, '123'),
(4, '12345');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `tid` int(11) NOT NULL,
  `date1` varchar(50) NOT NULL,
  `cid` int(11) NOT NULL,
  `tr_mode` varchar(20) NOT NULL,
  `amount` float NOT NULL,
  `balance` float NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`tid`, `date1`, `cid`, `tr_mode`, `amount`, `balance`, `name`) VALUES
(118, '03-01-2023', 7, 'dr', 5000, 4800, 'N Siddaraju'),
(119, '03-01-2023', 8, 'cr', 5000, 15500, 'N Siddaraju'),
(120, '03-01-2023', 7, 'dr', 200, 4600, 'N Siddaraju'),
(121, '03-01-2023', 7, 'cr', 2900, 7500, 'N Siddaraju'),
(122, '04-01-2023', 32, 'dr', 100, 400, 'manjunath t'),
(123, '04-01-2023', 32, 'dr', 100, 300, 'manjunath t'),
(140, '10-01-2023', 35, 'cr', 0, 500, 'chandra R'),
(141, '10-01-2023', 35, 'cr', 5000, 5500, 'chandra R'),
(142, '10-01-2023', 35, 'dr', 2000, 3500, 'chandra R'),
(143, '10-01-2023', 4, 'cr', 2000, 73545, 'Manjula R'),
(144, '10-01-2023', 35, 'dr', 500, 3000, 'chandra R'),
(145, '10-01-2023', 35, 'dr', -500, 3500, 'chandra R'),
(146, '10-01-2023', 35, 'cr', -500, 3000, 'chandra R');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`bkid`),
  ADD UNIQUE KEY `accnumber` (`account_no`),
  ADD UNIQUE KEY `account_no` (`account_no`);

--
-- Indexes for table `log_table`
--
ALTER TABLE `log_table`
  ADD PRIMARY KEY (`logid`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`tid`),
  ADD KEY `cid` (`cid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `bkid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `log_table`
--
ALTER TABLE `log_table`
  MODIFY `logid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `username` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `customer` (`bkid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
