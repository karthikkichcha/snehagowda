/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.io.PrintStream;
import static java.lang.Math.min;
import static java.lang.Math.min;
import java.util.Random;

/**
 *
 * @author HP
 */
public class Random_numbers {
    public static void main(String args[])
    {
        Random_numbers num=new Random_numbers();
        System.out.print(num.randnumber());
    }
       Random r=new Random();
       public String randnumber()
       {
//       int s=r.nextInt(1000)+1;
//       System.out.println(s);
      long min=100000008;
      long max=1237687808;
      long c=(long)(Math.random()*(max-min+1)+min);
       //System.out.println(c);
       String s="";
      // s=Long.parseLong(c)+"";
       s="MYS"+c;
        // System.out.println(s);
         return s;
        
    }
    
}
