/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author HP
 */
public class Connection_for_all {
    public static void main(String args[])
    {
        try
        {
        Connection_for_all a=new Connection_for_all();
        a.dbcon();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    public Connection dbcon() throws ClassNotFoundException
    {
        Connection con=null;
        try
        {
        
       Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/mysore_bank";
            String username="root";
            String password="";
            con = DriverManager.getConnection(url, username, password);
            if(con!=null)
            {
                System.out.println("Connection sucess");
            }
            else
            {
               System.out.println("problem with database Connection "); 
            }
        }
        catch(Exception e)
        {
        System.out.println(e);
        }
        return con;
        
    }
    
}
